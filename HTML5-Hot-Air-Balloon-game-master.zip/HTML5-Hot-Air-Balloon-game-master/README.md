HTML5-Hot-Air-Balloon-game
==========================

Hot Air Balloon game trial using HTML5

This was my first attempt at using HTML5 canvas to come up with a game.
HTML5 Libraries used:
CraftyJS - as primary game engine
Box2D - for physics engine

the game code is in the JS folder, as: game.js

there is a graph generated on the page, with its code on: CalculusGraph.js, also in the JS folder

